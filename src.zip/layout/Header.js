import React from 'react';
import '../style/common.css'
import { Link } from 'react-router-dom';   
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMagnifyingGlass } from '@fortawesome/free-solid-svg-icons';

function Header(props) {
  return (
    <header>
      <div className='header_wrap'>
        <div className='header_logo'>
          <Link to="/">
          <img
            src={`${process.env.PUBLIC_URL}/images/header_logo.png`}
            alt="메뉴보기"
          />
          </Link>
        </div>

        <div className='header_search_wrap'>
          <form>
            <FontAwesomeIcon icon={faMagnifyingGlass} className="header_search-icon" />
            <input>
              
            </input>
          </form>
        </div>

        <nav className='header_lnb_wrap'>
          <ul>
            <li><Link to="/login">로그인</Link></li>
            <li><Link to="/register">회원가입</Link></li>
            <li><Link to="/cart">장바구니</Link></li>
            <li><Link to="/">고객센터</Link></li>
          </ul>
        </nav>

        <nav className='header_gnb_wrap'>
          <ul>
            <li><Link to="/">중고마켓</Link></li>
            <li><Link to="/">그린기부</Link></li>
            <li><Link to="/">그린커뮤니티</Link></li>
          </ul>
        </nav>
      </div>
      </header>
  );
}

export default Header;