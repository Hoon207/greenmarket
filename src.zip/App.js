// src/App.js
import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';  // ← Routes, Route 추가
import './style/reset.css';
import './style/common.css';
import './style/App.css';

import Header from './layout/Header';
import Footer from './layout/Footer';
import Main from './components/Main';
import Cart from './components/Cart';
import Login from './components/Login';
import ItemDetail from './components/ItemDetail';
import Register from './components/Register';
// import OtherPage from './components/OtherPage';  // 필요하다면 추가

function App() {
  return (
    <BrowserRouter>
      <Header />

      {/* 페이지 컨텐츠 영역 */}

        <Routes>
 
          <Route path="/" element={<Main />} />
          <Route path="/" element={<ItemDetail />} />
          <Route path="/login" element={<Login />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/register" element={<Register />} />
          {/* <Route path="/other" element={<OtherPage />} /> */}
        </Routes>


      <Footer />
    </BrowserRouter>
  );
}

export default App;
