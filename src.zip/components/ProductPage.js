// components/ProductPage.js
import React, { useState, useMemo } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faChevronDown, faChevronUp, faSearch } from '@fortawesome/free-solid-svg-icons';
import '../style/productpage.css';        // ★ 스타일 경로 확인
import Slide from './Slide';
import ItemCard2 from './ItemCard2';
import itemData from '../data/itemData';  // 더미 또는 실제 데이터

/* ▣ itemData → 카드 배열로 평탄화 */
const productItems = Object.entries(itemData).flatMap(([rawCat, group]) => {
  const category = rawCat.replace('#', '').trim();
  return (group.items || []).map((it) => ({
    ...it,
    category,
    price: Number(String(it.price).replace(/[^0-9]/g, '')),
  }));
});

/* ▣ 상단 탭 옵션 */
const CATEGORY = [
  '여성 의류 (581,886)',
  '남성 의류 (539,968)',
  '가방 (73,507)',
  '신발 (130,001)',
  '패션잡화 (125,288)',
  '키즈 (49,638)',
  '라이프 (201,836)',
  '기타 (184,981)',
  '러그',               
  '상품명1',               
  '상품명2',                // 추가
];
const BRAND = [
  'Brand A',             // 추가
  '브랜드B',
  '브랜드C',
  '나이키 (12,693)',
  '아디다스 (17,688)',
  '자라 (10,085)',
  '유니클로 (3,973)',
  '폴로 랄프 로렌 (7,268)',
  '타미힐피거 (6,682)',
  '리바이스 (4,405)',
  '타임 (3,803)',
  '코스 (4,725)',
  '노스페이스 (7,226)',
];

function ProductPage() {
  /* ─ 상태 ─ */
  const [openKey, setOpenKey]       = useState(null);
  const [categories, setCategories] = useState([]);
  const [brands, setBrands]         = useState([]);
  const [priceMin, setPriceMin]     = useState('');
  const [priceMax, setPriceMax]     = useState('');
  const [searchInput, setSearchInput] = useState('');
  const [searchTerm, setSearchTerm]   = useState('');

  /* ─ 헬퍼 ─ */
  const toggleArray = (val, setter) =>
    setter((prev) => (prev.includes(val) ? prev.filter((v) => v !== val) : [...prev, val]));

  /* 검색 입력 */
  const handleSearchChange = (e) => {
    const val = e.target.value;
    setSearchInput(val);
    if (val.trim() === '') setSearchTerm('');
  };
  const handleSearchKey = (e) => {
    if (e.key === 'Enter') setSearchTerm(searchInput.trim());
  };

  /* ─ 최종 필터링 ─ */
  const filtered = useMemo(() => {
    return productItems.filter((item) => {
      /* ★ 카테고리 매칭: 선택값이 category 또는 name 에 포함되는지 */
      if (
        categories.length &&
        !categories.some((c) => item.category.includes(c) || item.name.includes(c))
      )
        return false;

      if (brands.length && !brands.includes(item.brand)) return false;
      if (priceMin && item.price < Number(priceMin)) return false;
      if (priceMax && item.price > Number(priceMax)) return false;

      if (searchTerm && !item.name.toLowerCase().includes(searchTerm.toLowerCase()))
        return false;

      return true;
    });
  }, [categories, brands, priceMin, priceMax, searchTerm]);

  /* ─ UI ─ */
  return (
    <>
      <Slide />

      <div className="productpage_wrap">
        {/* ─ 탭 ─ */}
        <ul className="productpage_tab-list">
          {['category', 'brand', 'price', 'etc'].map((key, idx) => {
            const titles = ['카테고리', '브랜드', '가격', '기타'];
            const badge =
              key === 'category' ? categories.length :
              key === 'brand'    ? brands.length :
              key === 'price' && (priceMin || priceMax) ? 1 : 0;
            return (
              <li
                key={key}
                className={`productpage_tab-item ${openKey === key ? 'active' : ''}`}
                onClick={() => setOpenKey(openKey === key ? null : key)}
              >
                {titles[idx]}
                <FontAwesomeIcon icon={openKey === key ? faChevronUp : faChevronDown} />
                {badge > 0 && <em>{badge}</em>}
              </li>
            );
          })}
        </ul>

        {/* ─ 패널: 카테고리 ─ */}
        {openKey === 'category' && (
          <div className="productpage_panel">
            <ul className="productpage_grid">
              {CATEGORY.map((c) => (
                <li key={c} onClick={() => toggleArray(c, setCategories)}>{c}</li>
              ))}
            </ul>
          </div>
        )}

        {/* ─ 패널: 브랜드 ─ */}
        {openKey === 'brand' && (
          <div className="productpage_panel">
            <ul className="productpage_grid">
              {BRAND.map((b) => (
                <li key={b} onClick={() => toggleArray(b, setBrands)}>{b}</li>
              ))}
            </ul>
          </div>
        )}

        {/* ─ 패널: 가격 ─ */}
        {openKey === 'price' && (
          <div className="productpage_panel productpage_price">
            <input
              type="number"
              placeholder="최저금액"
              value={priceMin}
              onChange={(e) => setPriceMin(e.target.value)}
            />
            원&nbsp;부터&nbsp;~
            <input
              type="number"
              placeholder="최고금액"
              value={priceMax}
              onChange={(e) => setPriceMax(e.target.value)}
            />
            원&nbsp;까지&nbsp;
            <button onClick={() => setOpenKey(null)}>적용하기</button>
          </div>
        )}

        {/* ─ 선택 필터 바 ─ */}
        {(categories.length || brands.length || priceMin || priceMax) && (
          <div className="productpage_filter-bar">
            <button onClick={() => { setCategories([]); setBrands([]); setPriceMin(''); setPriceMax(''); }}>
              필터초기화 ↺
            </button>

            {categories.map((c) => (
              <span key={c}>{c} <b onClick={() => toggleArray(c, setCategories)}>×</b></span>
            ))}
            {brands.map((b) => (
              <span key={b}>{b} <b onClick={() => toggleArray(b, setBrands)}>×</b></span>
            ))}
            {(priceMin || priceMax) && (
              <span>
                {priceMin || 0}원 ~ {priceMax || '∞'}원
                <b onClick={() => { setPriceMin(''); setPriceMax(''); }}>×</b>
              </span>
            )}
          </div>
        )}

        {/* ─ 검색창 ─ */}
        <div className="productpage_search" style={{ marginTop: 30 }}>
          <FontAwesomeIcon icon={faSearch} />
          <input
            placeholder="상품명을 입력하고 Enter"
            value={searchInput}
            onChange={handleSearchChange}
            onKeyDown={handleSearchKey}
          />
        </div>

        {/* ─ 상품 리스트 ─ */}
        <ul className="productpage_items_list">
          {filtered.map((it) => (
            <ItemCard2
              key={`${it.category}-${it.id}`}
              imgSrc={`${process.env.PUBLIC_URL}${it.image}`}
              brand={it.brand}
              name={it.name}
              price={`${it.price.toLocaleString()}원`}
              time={it.time}
            />
          ))}
        </ul>
      </div>
    </>
  );
}

export default ProductPage;
