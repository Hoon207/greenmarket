// components/ItemCard2.js
import React from 'react';
import '../style/itemcard2.css';

function ItemCard2({ imgSrc, brand, name, price, time }) {
  return (
    <li className="itemcard2">
      <img src={imgSrc} alt={name} className="item" />
      <span className="brand2">{brand}</span>
      <p className="item_name">{name}</p>
      <p className="price">{price}</p>
      <p className="register_time">{time}</p>
    </li>
  );
}

export default ItemCard2;