import React, { useState } from 'react';
import '../style/cart.css'; 
function Cart() {
  const [ItemData, setItemData] = useState([
    {
      id: 1,
      name: '아디다스 점퍼',
      category: '의류',
      price: 12000,
      ship:0,
      image: `${process.env.PUBLIC_URL}/images/item_img1.jpg`,
      checked: false,
    },
    {
      id: 2,
      name: '아디다스 점퍼',
      category: '의류',
      price: 8000,
      ship:2500,
      image: `${process.env.PUBLIC_URL}/images/item_img1.jpg`,
      checked: false,
    },
  ]);

  const handleCheck = (id) => {
    setItemData(prev =>
      prev.map(item =>
        item.id === id ? { ...item, checked: !item.checked } : item
      )
    );
  };

  const handleDeleteSelected = () => {
    setItemData(prev => prev.filter(item => !item.checked));
  };

  const handleDeleteAll = () => {
    setItemData([]);
  };

  const handleDeleteSingle = (id) => {
    setItemData(prev => prev.filter(item => item.id !== id));
  };

  const selectedItems = ItemData.filter(item => item.checked);
  const itemsTotal = selectedItems.reduce((sum, item) => sum + item.price, 0);
  const shippingTotal = selectedItems.reduce((sum, item) => sum + item.ship, 0);
  const totalPrice = itemsTotal + shippingTotal;

  return (
    <div className='cart_wrap'>
      <h2 className='cart_wrap_title'>장바구니</h2>

      <div style={{ marginBottom: '10px' }}>
        <button onClick={handleDeleteSelected}>선택 삭제</button>{' '}
        <button onClick={handleDeleteAll}>모두 삭제</button>
      </div>

      <table className="cart_table">
        <thead>
          <tr>
            <th>선택</th>
            <th>상품 이미지</th>
            <th>상품명</th>
            <th>카테고리</th>
            <th>가격</th>
            <th>배송비</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {ItemData.length === 0 ? (
            <tr style={{borderBottom:'none'}}>
        <td colSpan="7">장바구니에 담긴 상품이 없습니다.</td>
          </tr>
          ) : (
            ItemData.map(item => (
              <tr key={item.id}>
                <td>
                  <input
                    type="checkbox"
                    checked={item.checked}
                    onChange={() => handleCheck(item.id)}
                  />
                </td>
                <td>
                  <img src={item.image} alt={item.name} width="80" />
                </td>
                <td>{item.name}</td>
                <td>{item.category}</td>
                <td>{item.price.toLocaleString()}원</td>
                <td>{item.ship === 0 ? '무료' : `${item.ship.toLocaleString()}원`}</td>

                <td>
                  <button className='cart_btn_buy' onClick={() => alert(`${item.name} 구매하기`)}>구매</button>{' '}
                  <br></br><button className='cart_btn_delete' onClick={() => handleDeleteSingle(item.id)}>삭제</button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>

      {selectedItems.length > 0 && (
        <div style={{ marginTop: '20px', textAlign: 'right' }}>
          선택된 상품: <strong>{selectedItems.length}개</strong> / 합계:{' '}
          <strong>{totalPrice.toLocaleString()}원</strong>
        </div>
      )}
    </div>
  );
}

export default Cart;
