import React from 'react';
import MainTab from './MainTab';
import Slide from './Slide';
import Upcon from './Upcon';
import MainList1 from './MainList1';
import MainList2 from './MainList2';
import MainList3 from './MainList3';

function Main(props) {
  return (
    <>
      <Slide />

      <Upcon />
      <MainList1 />
      <MainTab />
      <MainList2 />
      <MainList3 />
      
    </>
  );
}

export default Main;