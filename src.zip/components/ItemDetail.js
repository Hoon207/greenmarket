import React from 'react';
import '../style/common.css';
import { Swiper, SwiperSlide } from 'swiper/react';
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import 'swiper/css/scrollbar';
import { Navigation, Pagination } from 'swiper/modules';
import itemData from '../data/itemData';
import { useParams } from 'react-router-dom';
import '../style/ItemDetail.css';
import {Link} from 'react-router-dom';

function ItemDetail(props) {
  const { category, id } = useParams();

  const item = itemData[decodeURIComponent(category)]?.items.find(
    item => String(item.id) === id
  );

  if (!item) {
    return <div>상품을 찾을 수 없습니다.</div>;
  }

  return (
    <>
    <div className='category_info'>개별 상품의 판매 등록시 선택했던 카테고리 정보 출력</div>
    <div className='item_detail_wrap'>
      <div className='detail_top_wrap'>
        <div className='slide_wrap'>
          <Swiper
            modules={[Navigation, Pagination]}
            spaceBetween={0}
            slidesPerView={1}
            slidesPerGroup={1}
            navigation
            pagination={{ clickable: true }}
            className='detailSlide'
            loop={true}
          >
            
              <SwiperSlide className='item_detail_slide'>
                <img
                  src={`${process.env.PUBLIC_URL}/images/item_img1.jpg`}
                  alt=''
                  className='item_detail_img'
                />
              </SwiperSlide>

              <SwiperSlide className='item_detail_slide'>
                <img
                  src={`${process.env.PUBLIC_URL}/images/item_img2.jpg`}
                  alt=''
                  className='item_detail_img'
                />
              </SwiperSlide>

              <SwiperSlide className='item_detail_slide'>
                <img
                  src={`${process.env.PUBLIC_URL}/images/item_img3.jpg`}
                  alt=''
                  className='item_detail_img'
                />
              </SwiperSlide>

              <SwiperSlide className='item_detail_slide'>
                <img
                  src={`${process.env.PUBLIC_URL}/images/item_img4.jpg`}
                  alt=''
                  className='item_detail_img'
                />
              </SwiperSlide>
          
          </Swiper>
        </div>

        <div className='profile_wrap'>
          <div className='seller_profile'>
            <div className='seller_img_wrap'>
              <img
                src={`${process.env.PUBLIC_URL}/images/seller_img.png`}
                alt='판매자프로필사진'
                className='seller_profile_img'
              />
            </div>
            <div className='seller_info'>
              <p className='seller_id'>환경사랑12</p>
              <p className='seller_items'>판매중 1개</p>
            </div>
          </div>
        </div>
      </div>

      <div className='item_info'>
        <div>
        <p className='item_name'>{item.name}</p>
          <p className='price'>{item.price?.toLocaleString()}원</p>
          <hr className='hr' />
          <ul className='item_status'>
            <li>상품상태: {item.condition}</li>
            <li>배송비: {item.shippingCost}</li>
            <li>직거래: {item.directTrade || '직거래 불가'}</li>
          </ul>
        </div>
        <div className='item_btns_wrap'>
          <ul className='item_btns'>
            <li><button className='btn_question'>1:1문의</button></li>
            <li><button className='btn_cart'>관심</button></li>
            <Link to='/cart'><li><button className='btn_buy'>구매</button></li></Link>
          </ul>
        </div>
      </div>
    </div>
    <div className='item_textbox'>
    상품상세설명 들어갈 곳. 판매등록 폼태그에서 상세설명을 여기로 출력
    </div>

    <div className='seller_recommend'>
      판매자의 판매중인 다른 물건 목록: 메인페이지의 상품목록과 같음
    </div>

    <div className='category_recommend'>
     현재 보고 있는 상품과 카테고리가 같은 물건 목록: 메인페이지의 상품목록과 같음
    </div>
    </>
        
    
  );
}

export default ItemDetail;
