import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate, useParams } from 'react-router-dom';

function MemberUpdate() {
  const {num} = useParams(); // 파라미터값 받음
  const [form, setForm] = useState({
    username: '',
    userid: '',
    password: '',
    phone: '',
    email: '',
    region: ''
  });
  const navigate = useNavigate();

  // 발송 데이터 통신 성공여부 확인 출력
  useEffect(() => {
    axios
    .get(`http://localhost:9070/member/${num}`) // 전체 조회된 내용 중 숫자를 get방식으로 하여 해당 내용 조회.
    .then(res => {
      console.log('서버 응답값 : ', res.data);
      setForm(res.data);
    })
    .catch(err => console.log('조회 오류 : ', err));
  }, [num]);

  // 양식에 입력한 내용 저장
  const handleChange = (e) => {
    setForm({...form, [e.target.name]: e.target.value});
  }

  // 수정 메뉴 클릭시 실행
  const handleSubmit = (e) => {
    e.preventDefault();

    axios
    .put(`http://localhost:9070/member/update/${num}`, {
      username: form.name,
      userid: form.userid,
      password: form.password,
      phone: form.phone,
      emial: form.email,
      region: form.region
    })
    .then(() => {
      alert('수정이 완료되었습니다.');
      navigate('/');
    })
    .catch(err => console.log('수정 오류 : ', err));
  }

  return (
    <section>
      <form className='logform' onSubmit={handleSubmit}>
        <fieldset>
          <legend>회원정보 수정</legend>
          <p>
            <label htmlFor='logform_username'>성함</label>
            <input type='text' id='logform_username' name='username' required maxLength='10' value={form.username} onChange={handleChange} />
          </p>
          <p>
            <label htmlFor='logform_userid'>아이디</label>
            <input type='text' id='logform_userid' name='userid' required maxLength='30' value={form.userid} onChange={handleChange} />
          </p>
          <p>
            <label htmlFor='logform_password'>비밀번호</label>
            <input type='password' id='logform_password' name='password' required maxLength='40' value={form.password} onChange={handleChange} />
          </p>
          <p>
            <label htmlFor='logform_phone'>휴대전화</label>
            <input type='tel' id='logform_phone' name='phone' required maxLength='13' value={form.phone} onChange={handleChange} />
          </p>
          <p>
            <label htmlFor='logform_email'>이메일</label>
            <input type='email' id='logform_email' name='email' required maxLength='40' value={form.email} onChange={handleChange} />
          </p>
          <p>
            <label htmlFor='logform_region'>지역</label>
            <input type='text' id='logform_region' name='region' maxLength='40' value={form.region} onChange={handleChange} />
          </p>

          <p className='logform_update'><input type='submit' value='수정하기' /></p>
          <p className='logform_cancel'><Link to='/' title='취소'>취소</Link></p>
        </fieldset>
      </form>
    </section>
  );
}

export default MemberUpdate;