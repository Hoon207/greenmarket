// ItemCard2.js
import { Link } from 'react-router-dom';

function ItemCard2({ id, imgSrc, brand, name, price, time }) {
  return (
    <Link to={`/products/${id}`} className="item_card_link">
      <div className="item_card">
        <img src={imgSrc} alt={name} />
        <div className="item_info">
          <p>{brand}</p>
          <p>{name}</p>
          <p>{price}</p>
          <p>{time}</p>
        </div>
      </div>
    </Link>
  );
}


export default ItemCard2;
